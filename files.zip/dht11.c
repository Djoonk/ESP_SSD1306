#include "dht11.h"
#include "driver/gpio.h"
#include "esp_rom_sys.h"   /* esp_rom_delay_us() */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

/* ------------------------------------------------------------------ */
/*  Low-level GPIO helpers                                              */
/* ------------------------------------------------------------------ */

static inline void pin_output(void)
{
    gpio_set_direction(DHT11_GPIO, GPIO_MODE_OUTPUT);
}

static inline void pin_input(void)
{
    gpio_set_direction(DHT11_GPIO, GPIO_MODE_INPUT);
}

static inline void pin_high(void) { gpio_set_level(DHT11_GPIO, 1); }
static inline void pin_low(void)  { gpio_set_level(DHT11_GPIO, 0); }
static inline int  pin_read(void) { return gpio_get_level(DHT11_GPIO); }

/* ------------------------------------------------------------------ */
/*  Wait for pin level with timeout                                     */
/*  Returns elapsed µs, or -1 on timeout.                              */
/* ------------------------------------------------------------------ */

static int wait_for(int level, int timeout_us)
{
    int elapsed = 0;
    while (pin_read() != level)
    {
        if (elapsed >= timeout_us) return -1;
        esp_rom_delay_us(1);
        elapsed++;
    }
    return elapsed;
}

/* ------------------------------------------------------------------ */
/*  Public API                                                          */
/* ------------------------------------------------------------------ */

esp_err_t dht11_read(dht11_data_t *out)
{
    uint8_t data[5] = {0};

    /* --- 1. Send start signal ------------------------------------ */
    pin_output();
    pin_low();
    vTaskDelay(pdMS_TO_TICKS(20));   /* pull low ≥ 18 ms           */
    pin_high();
    esp_rom_delay_us(30);            /* pull high 20–40 µs         */
    pin_input();

    /* --- 2. Wait for DHT11 response ----------------------------- */
    if (wait_for(0, 100) < 0) return ESP_ERR_TIMEOUT;  /* low  80µs */
    if (wait_for(1, 100) < 0) return ESP_ERR_TIMEOUT;  /* high 80µs */
    if (wait_for(0, 100) < 0) return ESP_ERR_TIMEOUT;  /* data start*/

    /* --- 3. Read 40 bits (5 bytes) ------------------------------ */
    for (int byte = 0; byte < 5; byte++)
    {
        for (int bit = 7; bit >= 0; bit--)
        {
            /* Each bit starts with ~50µs low pulse */
            if (wait_for(1, 70) < 0) return ESP_ERR_TIMEOUT;

            /* Measure high pulse:
               26–28 µs → bit 0
               70    µs → bit 1                                    */
            int high_us = wait_for(0, 90);
            if (high_us < 0) return ESP_ERR_TIMEOUT;

            if (high_us > 40)
                data[byte] |= (1u << bit);
        }
    }

    /* --- 4. Verify checksum ------------------------------------- */
    uint8_t checksum = data[0] + data[1] + data[2] + data[3];
    if (checksum != data[4])
        return ESP_ERR_INVALID_CRC;

    /* --- 5. Parse result ---------------------------------------- */
    out->humidity    = (float)data[0] + (float)data[1] * 0.1f;
    out->temperature = (float)data[2] + (float)data[3] * 0.1f;

    return ESP_OK;
}
