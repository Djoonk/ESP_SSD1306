#ifndef DHT11_H
#define DHT11_H

#include <stdint.h>
#include "esp_err.h"

/* GPIO pin connected to DHT11 DATA line */
#define DHT11_GPIO  4

/* Result structure */
typedef struct {
    float temperature;  /* Celsius   */
    float humidity;     /* % RH      */
} dht11_data_t;

/**
 * @brief  Read temperature and humidity from DHT11.
 * @param  out  Pointer to result structure.
 * @return ESP_OK on success, ESP_ERR_TIMEOUT or ESP_ERR_INVALID_CRC on failure.
 */
esp_err_t dht11_read(dht11_data_t *out);

#endif /* DHT11_H */
