#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "ssd1306.h"
#include "i2c.h"
#include "dht11.h"

static const char *TAG = "main";

void app_main(void)
{
    i2c_init();
    ssd1306_init();

    dht11_data_t sensor = {0};
    char line1[24];  /* "Temp: 25 C"  */
    char line2[24];  /* "Hum:  60 %"  */

    while (1)
    {
        esp_err_t ret = dht11_read(&sensor);

        ssd1306_fill(SSD1306_BLACK);

        if (ret == ESP_OK)
        {
            snprintf(line1, sizeof(line1), "Temp: %d C", (int)sensor.temperature);
            snprintf(line2, sizeof(line2), "Hum:  %d %%", (int)sensor.humidity);

            ssd1306_draw_string(0, 0,  line1);
            ssd1306_draw_string(0, 16, line2);

            ESP_LOGI(TAG, "Temp: %.1f C  Hum: %.1f %%",
                     sensor.temperature, sensor.humidity);
        }
        else
        {
            ssd1306_draw_string(0, 0,  "DHT11 error");
            ESP_LOGE(TAG, "Read failed: %s", esp_err_to_name(ret));
        }

        ssd1306_update();

        vTaskDelay(pdMS_TO_TICKS(2000));  /* DHT11 мін. інтервал 2 с */
    }
}
